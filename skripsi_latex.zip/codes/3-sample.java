package com.sample;
import java.util.List;

public interface Sample {
    String sample();
}
