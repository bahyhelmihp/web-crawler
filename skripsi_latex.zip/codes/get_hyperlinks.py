def get_hyperlinks(url):
    """Return all absolute hyperlinks within the home url"""

    base_url = url_format_handler(url)
    session = HTMLSession()
    r = session.get(base_url, headers = {'User-Agent': np.random.choice(user_agent_list)}, timeout=30)
    res = list(r.html.absolute_links)
    
    ## If r-html anchor failed, concate manually
    res_final = [""]
    for url in res:
        if not str(url).startswith("http"):  
            res_final.append(str(base_url + url))
        else:
            res_final.append(str(url))

    ## Check if domain expired/redirects
    domain = base_url.split("//")[1]
    if any(domain in url for url in res_final):
        pass
    else:
        res_final = [""]

    ## If website does not return hyperlink
    if len(res) == 0 or len(res_final) == 0:
        res = [""]
    else:
        res = res_final

    return res